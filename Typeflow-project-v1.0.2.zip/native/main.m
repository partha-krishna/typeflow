#import <AppKit/AppKit.h>
#import <ApplicationServices/ApplicationServices.h>

@interface TypeflowApp : NSObject <NSApplicationDelegate>
@property(nonatomic) NSStatusItem *statusItem;
@property(nonatomic) CFMachPortRef tap;
@property(nonatomic) NSPanel *panel;
@property(nonatomic) NSString *word;
@property(nonatomic) NSString *previousWord;
@property(nonatomic) NSString *candidate;
@property(nonatomic) BOOL dismissed;
@property(nonatomic) BOOL enabled;
@property(nonatomic) BOOL listenerActive;
@property(nonatomic) BOOL listenAccess;
@property(nonatomic) BOOL postAccess;
@property(nonatomic) BOOL accessibilityAccess;
@end

static CGEventRef TypeflowEvent(CGEventTapProxy proxy, CGEventType type, CGEventRef event, void *info);

@implementation TypeflowApp
- (void)applicationDidFinishLaunching:(NSNotification *)note {
    [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];
    self.word = @""; self.previousWord = @""; self.candidate = @""; self.enabled = YES;
    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    self.statusItem.button.title = @"t."; self.statusItem.button.toolTip = @"Typeflow — system-wide word completion";
    [self requestPermissionsAndStart];
}
- (void)buildMenu {
    NSMenu *menu = [NSMenu new];
    NSString *state = self.listenerActive ? @"Keyboard listener active" : @"Keyboard listener blocked";
    NSMenuItem *title = [[NSMenuItem alloc] initWithTitle:state action:nil keyEquivalent:@""]; title.enabled = NO; [menu addItem:title];
    NSMenuItem *listen = [[NSMenuItem alloc] initWithTitle:[NSString stringWithFormat:@"Input Monitoring: %@", self.listenAccess ? @"Granted" : @"Permission needed"] action:nil keyEquivalent:@""]; listen.enabled = NO; [menu addItem:listen];
    NSMenuItem *accessibility = [[NSMenuItem alloc] initWithTitle:[NSString stringWithFormat:@"Accessibility: %@", self.accessibilityAccess ? @"Granted" : @"Permission needed"] action:nil keyEquivalent:@""]; accessibility.enabled = NO; [menu addItem:accessibility];
    NSMenuItem *posting = [[NSMenuItem alloc] initWithTitle:[NSString stringWithFormat:@"Text insertion: %@", self.postAccess ? @"Granted" : @"Permission needed"] action:nil keyEquivalent:@""]; posting.enabled = NO; [menu addItem:posting];
    [menu addItem:NSMenuItem.separatorItem];
    NSMenuItem *retry = [[NSMenuItem alloc] initWithTitle:@"Request / Retry Keyboard Access…" action:@selector(requestPermissionsAndStart) keyEquivalent:@""]; retry.target = self; [menu addItem:retry];
    NSMenuItem *accessibilitySettings = [[NSMenuItem alloc] initWithTitle:@"Open Accessibility Settings" action:@selector(openAccessibilitySettings) keyEquivalent:@""]; accessibilitySettings.target = self; [menu addItem:accessibilitySettings];
    NSMenuItem *inputSettings = [[NSMenuItem alloc] initWithTitle:@"Open Input Monitoring Settings" action:@selector(openPermissions) keyEquivalent:@""]; inputSettings.target = self; [menu addItem:inputSettings];
    [menu addItem:NSMenuItem.separatorItem];
    NSMenuItem *toggle = [[NSMenuItem alloc] initWithTitle:(self.enabled ? @"Pause suggestions" : @"Resume suggestions") action:@selector(toggle) keyEquivalent:@"p"]; toggle.target = self; [menu addItem:toggle];
    NSMenuItem *quit = [[NSMenuItem alloc] initWithTitle:@"Quit Typeflow" action:@selector(quit) keyEquivalent:@"q"]; quit.target = self; [menu addItem:quit];
    self.statusItem.menu = menu;
}
- (void)requestPermissionsAndStart {
    NSDictionary *options = @{(__bridge id)kAXTrustedCheckOptionPrompt: @YES};
    self.accessibilityAccess = AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)options);
    self.listenAccess = CGPreflightListenEventAccess();
    if (!self.listenAccess) self.listenAccess = CGRequestListenEventAccess();
    self.postAccess = CGPreflightPostEventAccess();
    if (!self.postAccess) self.postAccess = CGRequestPostEventAccess();
    if (!self.tap) [self startTap];
    [self buildMenu];
}
- (void)startTap {
    CGEventMask mask = CGEventMaskBit(kCGEventKeyDown);
    self.tap = CGEventTapCreate(kCGSessionEventTap, kCGHeadInsertEventTap, kCGEventTapOptionDefault, mask, TypeflowEvent, (__bridge void *)self);
    if (!self.tap) {
        self.listenerActive = NO; [self buildMenu]; return;
    }
    self.listenerActive = YES; [self buildMenu];
    CFRunLoopSourceRef source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, self.tap, 0);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), source, kCFRunLoopCommonModes); CFRelease(source);
    CGEventTapEnable(self.tap, true);
}
- (void)handleEvent:(CGEventRef)event {
    if (!self.enabled) return;
    if ([self isFocusedFieldSecure]) { self.word = @""; self.candidate = @""; self.dismissed = NO; dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; }); return; }
    CGEventFlags flags = CGEventGetFlags(event);
    if (flags & (kCGEventFlagMaskCommand | kCGEventFlagMaskControl | kCGEventFlagMaskAlternate)) return;
    CGKeyCode code = (CGKeyCode)CGEventGetIntegerValueField(event, kCGKeyboardEventKeycode);
    UniChar chars[8] = {0}; UniCharCount length = 0; CGEventKeyboardGetUnicodeString(event, 8, &length, chars);
    NSString *typed = [[NSString alloc] initWithCharacters:chars length:length];
    if (code == 51 || code == 117) {
        if (self.candidate.length && !self.dismissed) { self.dismissed = YES; dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; }); CGEventSetType(event, kCGEventNull); return; }
        if (code == 51 && self.word.length) { self.word = [self.word substringToIndex:self.word.length - 1]; [self updateCandidate]; }
        return;
    }
    if ([typed isEqualToString:@" "] || code == 49) {
        if (self.candidate.length && !self.dismissed) {
            NSString *insert = [[self.candidate substringFromIndex:MIN(self.word.length, self.candidate.length)] stringByAppendingString:@" "];
            self.previousWord = self.candidate; self.word = @""; self.candidate = @""; self.dismissed = NO;
            dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; [self postText:insert]; }); CGEventSetType(event, kCGEventNull); return;
        }
        self.previousWord = self.word.lowercaseString; self.word = @""; self.candidate = @""; self.dismissed = NO;
        dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; }); return;
    }
    if (code == 53) { if (self.candidate.length && !self.dismissed) { self.dismissed = YES; dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; }); CGEventSetType(event, kCGEventNull); } return; }
    NSCharacterSet *letters = [NSCharacterSet letterCharacterSet];
    BOOL valid = typed.length > 0;
    for (NSUInteger i = 0; i < typed.length; i++) { unichar c = [typed characterAtIndex:i]; if (![letters characterIsMember:c] && c != '\'' && c != 0x2019) { valid = NO; break; } }
    if (valid) { self.word = [self.word stringByAppendingString:typed.lowercaseString]; self.dismissed = NO; [self updateCandidate]; }
    else if (code == 36 || code == 76 || [@[@".", @",", @"!", @"?", @"\n", @"\t"] containsObject:typed]) {
        self.previousWord = self.word.lowercaseString; self.word = @""; self.candidate = @""; self.dismissed = NO; dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; });
    }
}
- (BOOL)isFocusedFieldSecure {
    pid_t pid = NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier;
    AXUIElementRef app = AXUIElementCreateApplication(pid); CFTypeRef focused = NULL;
    if (AXUIElementCopyAttributeValue(app, kAXFocusedUIElementAttribute, &focused) != kAXErrorSuccess) { CFRelease(app); return NO; }
    CFTypeRef subrole = NULL; BOOL secure = NO;
    if (AXUIElementCopyAttributeValue((AXUIElementRef)focused, kAXSubroleAttribute, &subrole) == kAXErrorSuccess) { NSString *s = CFBridgingRelease(subrole); secure = [s.lowercaseString containsString:@"secure"]; }
    CFRelease(focused); CFRelease(app); return secure;
}
- (void)updateCandidate {
    NSArray *words = @[@"the",@"and",@"you",@"your",@"that",@"this",@"with",@"for",@"from",@"have",@"will",@"can",@"would",@"could",@"should",@"because",@"when",@"what",@"where",@"which",@"quick",@"brown",@"fox",@"thought",@"idea",@"meeting",@"project",@"today",@"tomorrow",@"important",@"really",@"write",@"typing",@"suggestion",@"sentence",@"finish",@"word",@"words",@"help",@"make",@"more",@"less",@"than",@"then",@"there",@"their",@"they",@"we",@"are",@"was",@"is",@"it",@"in",@"on",@"to",@"of",@"a",@"an",@"my",@"our",@"about",@"just",@"like",@"know",@"think",@"feel",@"want",@"need",@"please",@"thanks",@"hello",@"great",@"good",@"also",@"not",@"but",@"if",@"as",@"at",@"by",@"be",@"do",@"done",@"go",@"get",@"see",@"look",@"use",@"time",@"work",@"fast",@"faster",@"note",@"draft",@"simple",@"easy",@"best",@"new",@"morning",@"forward",@"am"];
    NSDictionary *preferred = @{@"the":@[@"quick",@"best",@"new",@"idea",@"project"],@"quick":@[@"brown"],@"brown":@[@"fox"],@"i":@[@"think",@"want",@"need",@"would",@"can",@"have",@"am"],@"thank":@[@"you"],@"looking":@[@"forward"],@"see":@[@"you"],@"what":@[@"do",@"would",@"is"],@"how":@[@"are",@"do",@"to"],@"in":@[@"the"],@"on":@[@"the"],@"for":@[@"the"],@"would":@[@"like"],@"can":@[@"you"],@"we":@[@"can",@"should",@"will"],@"let":@[@"me"],@"good":@[@"morning",@"idea"],@"please":@[@"let",@"send",@"see"],@"tomorrow":@[@"morning"]};
    NSMutableArray *matches = [NSMutableArray new];
    for (NSString *candidate in words) if ([candidate hasPrefix:self.word] && ![candidate isEqualToString:self.word]) [matches addObject:candidate];
    [matches sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) { BOOL ap = [preferred[self.previousWord] containsObject:a], bp = [preferred[self.previousWord] containsObject:b]; if (ap != bp) return ap ? NSOrderedAscending : NSOrderedDescending; return a.length < b.length ? NSOrderedAscending : (a.length > b.length ? NSOrderedDescending : NSOrderedSame); }];
    self.candidate = matches.firstObject ?: @""; self.dismissed = NO;
    if (!self.candidate.length) { dispatch_async(dispatch_get_main_queue(), ^{ [self hidePanel]; }); return; }
    dispatch_async(dispatch_get_main_queue(), ^{ [self showSuggestion]; });
}
- (CGRect)caretBounds {
    pid_t pid = NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier;
    AXUIElementRef app = AXUIElementCreateApplication(pid); CFTypeRef focused = NULL;
    if (AXUIElementCopyAttributeValue(app, kAXFocusedUIElementAttribute, &focused) != kAXErrorSuccess) { CFRelease(app); return CGRectNull; }
    AXUIElementRef element = (AXUIElementRef)focused; CFTypeRef subrole = NULL;
    if (AXUIElementCopyAttributeValue(element, kAXSubroleAttribute, &subrole) == kAXErrorSuccess) { NSString *s = CFBridgingRelease(subrole); if ([s.lowercaseString containsString:@"secure"]) { CFRelease(element); CFRelease(app); return CGRectNull; } }
    CFTypeRef rangeValue = NULL; CGRect rect = CGRectNull;
    if (AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute, &rangeValue) == kAXErrorSuccess) {
        CFRange range; if (AXValueGetValue((AXValueRef)rangeValue, kAXValueTypeCFRange, &range)) { AXValueRef axRange = AXValueCreate(kAXValueTypeCFRange, &range); CFTypeRef bounds = NULL; if (AXUIElementCopyParameterizedAttributeValue(element, kAXBoundsForRangeParameterizedAttribute, axRange, &bounds) == kAXErrorSuccess) { AXValueGetValue((AXValueRef)bounds, kAXValueTypeCGRect, &rect); CFRelease(bounds); } CFRelease(axRange); }
        CFRelease(rangeValue);
    }
    CFRelease(element); CFRelease(app); return rect;
}
- (void)showSuggestion {
    CGRect caret = [self caretBounds]; NSPoint origin;
    if (CGRectIsNull(caret)) { NSPoint mouse = NSEvent.mouseLocation; origin = NSMakePoint(mouse.x, mouse.y - 34); }
    else { NSScreen *screen = NSScreen.mainScreen; CGFloat height = screen.frame.size.height; origin = NSMakePoint(caret.origin.x, height - CGRectGetMaxY(caret) - 36); }
    NSString *title = [self.candidate stringByAppendingString:@"  ↵"];
    NSTextField *label = [NSTextField labelWithString:title]; label.font = [NSFont systemFontOfSize:13 weight:NSFontWeightMedium]; label.textColor = [NSColor colorWithCalibratedRed:.18 green:.31 blue:.23 alpha:1];
    CGFloat width = MAX(110, label.intrinsicContentSize.width + 24); NSView *view = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, width, 34)]; view.wantsLayer = YES; view.layer.cornerRadius = 8; view.layer.backgroundColor = [NSColor colorWithWhite:1 alpha:.98].CGColor; view.layer.borderWidth = 1; view.layer.borderColor = [NSColor colorWithWhite:.86 alpha:1].CGColor; label.frame = NSMakeRect(12, 8, width - 24, 18); [view addSubview:label];
    if (!self.panel) { self.panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0, 0, width, 34) styleMask:NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel backing:NSBackingStoreBuffered defer:NO]; self.panel.level = NSPopUpMenuWindowLevel; self.panel.backgroundColor = NSColor.clearColor; self.panel.opaque = NO; self.panel.hasShadow = YES; self.panel.ignoresMouseEvents = YES; self.panel.collectionBehavior = NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorFullScreenAuxiliary; }
    self.panel.contentView = view; [self.panel setFrameOrigin:origin]; [self.panel orderFrontRegardless];
}
- (void)hidePanel { [self.panel orderOut:nil]; }
- (void)postText:(NSString *)text {
    pid_t pid = NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier;
    for (NSUInteger i = 0; i < text.length; i++) { UniChar unit = [text characterAtIndex:i]; CGEventRef down = CGEventCreateKeyboardEvent(NULL, 0, true), up = CGEventCreateKeyboardEvent(NULL, 0, false); CGEventKeyboardSetUnicodeString(down, 1, &unit); CGEventKeyboardSetUnicodeString(up, 1, &unit); CGEventPostToPid(pid, down); CGEventPostToPid(pid, up); CFRelease(down); CFRelease(up); }
}
- (void)toggle { self.enabled = !self.enabled; if (!self.enabled) [self hidePanel]; [self buildMenu]; }
- (void)openPermissions { [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:@"x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent"]]; }
- (void)openAccessibilitySettings { [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:@"x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"]]; }
- (void)quit { [NSApp terminate:nil]; }
@end

static CGEventRef TypeflowEvent(CGEventTapProxy proxy, CGEventType type, CGEventRef event, void *info) {
    TypeflowApp *app = (__bridge TypeflowApp *)info;
    if (type == kCGEventTapDisabledByTimeout || type == kCGEventTapDisabledByUserInput) { if (app.tap) CGEventTapEnable(app.tap, true); return event; }
    if (type == kCGEventKeyDown) [app handleEvent:event];
    return CGEventGetType(event) == kCGEventNull ? NULL : event;
}

int main(int argc, const char *argv[]) {
    @autoreleasepool { NSApplication *app = NSApplication.sharedApplication; TypeflowApp *delegate = [TypeflowApp new]; app.delegate = delegate; [app run]; }
    return 0;
}
